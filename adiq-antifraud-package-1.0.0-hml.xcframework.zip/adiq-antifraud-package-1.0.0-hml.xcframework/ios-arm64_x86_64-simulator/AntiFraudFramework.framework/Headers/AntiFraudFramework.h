//
//  AntiFraudFramework.h
//  AntiFraudFramework
//
//  Created by Flavio Spedaletti on 11/11/24.
//

#import <Foundation/Foundation.h>

//! Project version number for AntiFraudFramework.
FOUNDATION_EXPORT double AntiFraudFrameworkVersionNumber;

//! Project version string for AntiFraudFramework.
FOUNDATION_EXPORT const unsigned char AntiFraudFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AntiFraudFramework/PublicHeader.h>


